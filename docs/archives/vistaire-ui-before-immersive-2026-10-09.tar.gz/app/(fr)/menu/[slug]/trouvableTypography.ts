export const trouvableTypographyClassName: string = "";
