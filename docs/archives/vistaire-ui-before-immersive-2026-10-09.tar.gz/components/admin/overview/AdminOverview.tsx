import Link from "next/link";
import type { AdminDashboardData } from "@/lib/admin/dashboardData";
import type { AdminDashboardRange } from "@/lib/admin/dashboardRange";
import { InteractiveDonut } from "../charts/InteractiveDonut";
import { AvailableDishIcon, DishViewsIcon, ImmersiveIcon, MenuOpenIcon, SearchIcon } from "../system/AdminIcons";
import { AdminShell } from "../system/AdminShell";
import { AdminEvidenceState, AdminKpiCard, AdminPanel } from "../system/AdminPrimitives";
import { AdminAvailabilityStrip } from "./AdminAvailabilityStrip";
import { AdminTopDishes } from "./AdminTopDishes";
import { AdminMetricLineChart } from "./AdminMetricLineChart";
import { buildServicePreview } from "./servicePreview";
import styles from "./AdminOverview.module.css";

const number = new Intl.NumberFormat("fr-CA");

export function AdminOverview({ data, range }: { data: AdminDashboardData; range: AdminDashboardRange }) {
  const analytics = data.analytics;
  const panels = analytics.kind === "real" ? analytics.panels : null;
  const metric = (id: string) => analytics.kind === "real" ? analytics.metrics.find((item) => item.id === id) : null;
  const fallback = { kind: analytics.kind === "unavailable" ? "unavailable" : "insufficient", reason: analytics.kind === "real" ? "no-evidence" : analytics.reason } as const;
  const dishMap = new Map(data.menu.dishes.map((dish) => [dish.slug, { name: dish.name, image: dish.thumbnailUrl || dish.imageUrl }]));
  const series = analytics.kind === "real" ? analytics.metricSeries : null;
  const categories = panels?.categories;
  const categoryTotal = categories?.kind === "supported" ? categories.data.reduce((sum, item) => sum + item.count, 0) : 0;
  const categoryPreview = categories?.kind !== "supported" || categories.data.length <= 4 ? categories?.kind === "supported" ? categories.data : [] : [
    ...categories.data.slice(0, 3),
    { slug: "__other__", label: "Autres", count: categories.data.slice(3).reduce((sum, item) => sum + item.count, 0) },
  ];
  const services = panels?.serviceWindows;
  const servicePreview = services?.kind === "supported" ? buildServicePreview(services.data.windows) : null;
  const serviceFallback = services?.kind === "supported" ? fallback : services ?? fallback;
  const comparisonLabel = range === "today-utc" ? "24 h" : range === "7d" ? "7 jours" : "30 jours";
  const change = (id: string) => {
    const rate = metric(id)?.changeRate;
    return rate === null || rate === undefined ? "Sans base comparable" : `${rate >= 0 ? "↗" : "↘"} ${Math.abs(Math.round(rate * 100))} % vs ${comparisonLabel}`;
  };
  const evidence = (id: string) => metric(id) ? undefined : fallback;
  const periodLabel = range === "today-utc" ? "Aujourd’hui" : range === "7d" ? "7 derniers jours" : "30 derniers jours";
  const headerStatus = <div className={styles.period}><span>Période analysée</span><strong>{periodLabel}</strong><em>Heures affichées en UTC</em></div>;

  return <AdminShell restaurantName={data.restaurant.name} menuPath={data.restaurant.publicMenuPath} active="overview" headerStatus={headerStatus}>
    <section className={styles.kpis} data-overview-kpis aria-label="Indicateurs clés">
      <AdminKpiCard label="Ouvertures du menu" value={metric("menu-opens") ? number.format(metric("menu-opens")!.value) : "—"} detail={metric("menu-opens") ? change("menu-opens") : undefined} evidence={evidence("menu-opens")} icon={<MenuOpenIcon/>}/>
      <AdminKpiCard label="Consultations de plats" value={metric("dish-opens") ? number.format(metric("dish-opens")!.value) : "—"} detail={metric("dish-opens") ? change("dish-opens") : undefined} evidence={evidence("dish-opens")} icon={<DishViewsIcon/>}/>
      <AdminKpiCard label="Recherches" value={metric("searches") ? number.format(metric("searches")!.value) : "—"} detail={metric("searches") ? change("searches") : undefined} evidence={evidence("searches")} icon={<SearchIcon/>}/>
      <AdminKpiCard className={styles.kpiImmersive} label="Interactions 3D/AR" value={metric("immersive") ? number.format(metric("immersive")!.value) : "—"} detail={metric("immersive") ? change("immersive") : undefined} evidence={evidence("immersive")} icon={<ImmersiveIcon/>}/>
      <AdminKpiCard label="Plats disponibles" value={`${data.menu.readiness.counts.available} / ${data.menu.readiness.counts.dishes}`} detail={`${Math.round(data.menu.readiness.counts.available / Math.max(1, data.menu.readiness.counts.dishes) * 100)} % du menu`} icon={<AvailableDishIcon/>}/>
    </section>
    <div className={styles.overviewGrid}>
      <AdminPanel className={styles.activity} data-overview-panel="activity" title="Activité du menu" action={<Link className={styles.insightsCta} href="/admin/insights">Voir les statistiques détaillées</Link>}>{series ? <AdminMetricLineChart series={series} period={range}/> : <AdminEvidenceState kind={fallback.kind} reason={fallback.reason}/>}</AdminPanel>
      <AdminPanel className={styles.top} data-overview-panel="ranking" title="Top plats consultés"><AdminTopDishes evidence={panels?.ranking ?? fallback} dishes={dishMap}/></AdminPanel>
      <AdminPanel className={styles.moment} data-overview-panel="moment" title="Activité par moment" eyebrow="Heures affichées en UTC">{servicePreview ? <InteractiveDonut data={servicePreview} title="Activité par moment" description="Répartition sur les trois moments de service" period={range} unit="interactions" summary="Déjeuner, après-midi et dîner couvrent toutes les interactions de la période."/> : <AdminEvidenceState kind={serviceFallback.kind} reason={serviceFallback.reason}/>}</AdminPanel>
      <AdminPanel className={styles.category} data-overview-panel="category" title="Activité par catégorie">{categories?.kind === "supported" ? <><ul className={styles.categoryBars}>{categoryPreview.map((item) => {
        const share = Math.round(item.count / Math.max(categoryTotal, 1) * 100);
        const label = item.label ?? "Catégorie du menu";
        return <li key={item.slug} aria-label={`${label} : ${number.format(item.count)} interactions, ${share} %`}><span>{label}</span><i aria-hidden="true" data-chart-animated="category-bar" style={{ "--value": `${share}%` } as React.CSSProperties}/><strong>{share} %</strong></li>;
      })}</ul><div className={styles.exactTable}><table><caption>Détail exact de l’activité par catégorie</caption><thead><tr><th>Catégorie</th><th>Interactions</th></tr></thead><tbody>{categories.data.map((item) => <tr key={item.slug}><th>{item.label ?? "Catégorie du menu"}</th><td>{item.count}</td></tr>)}</tbody></table></div></> : <AdminEvidenceState kind={(categories ?? fallback).kind as "insufficient" | "unavailable"} reason={(categories ?? fallback).reason}/>}</AdminPanel>
      <AdminPanel className={styles.availability} data-overview-panel="availability" title="Disponibilité des plats" action={<Link className={styles.stripLink} href="/admin/availability">Gérer les disponibilités</Link>}><AdminAvailabilityStrip dishes={data.menu.dishes}/></AdminPanel>
    </div>
  </AdminShell>;
}
